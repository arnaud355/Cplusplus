#ifndef FONCTIONS_H_INCLUDED
#define FONCTIONS_H_INCLUDED

std::string melangerLettres(std::string motAmelanger,int tailleMot);
std::string recupMot(int nbAlea);

#endif
