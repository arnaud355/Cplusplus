#ifndef H_DEFINE
#define H_DEFINE

#include <SDL.h>
#include <iostream>
#include <string>


const int WIDTH=800;
const int HEIGHT=600;

#endif
